# Result
[Splash-Screen.webm](https://user-images.githubusercontent.com/72277295/178153184-d8afce97-28ec-4499-ac7b-b014bbc4dd52.webm)
